from fastapi.testclient import TestClient
from backend.main import app

def test_health_and_demo():
    with TestClient(app) as c:
        h=c.get('/api/health');assert h.status_code==200 and h.json()['status']=='ok'
        d=c.get('/api/dashboard');assert d.status_code==200 and d.json()['incident_count']>=1
        assert c.get('/api/robotics/scenarios/demo-grid').status_code==200

def test_recommendation_accept_idempotent():
    with TestClient(app) as c:
        inc=c.get('/api/incidents').json()[0]
        r=c.post(f"/api/incidents/{inc['id']}/recommendations");assert r.status_code==200
        rid=r.json()['id'];a=c.post(f'/api/recommendations/{rid}/accept');assert a.status_code==200 and a.json()['recommendation']['status']=='ACCEPTED'
        b=c.post(f'/api/recommendations/{rid}/accept');assert b.status_code==200 and b.json()['idempotent'] is True

def test_override_requires_reason():
    with TestClient(app) as c:
        inc=c.get('/api/incidents').json()[0];r=c.post(f"/api/incidents/{inc['id']}/recommendations").json()
        bad=c.post(f"/api/recommendations/{r['id']}/override",json={'reason':'no'});assert bad.status_code==422
        ok=c.post(f"/api/recommendations/{r['id']}/override",json={'reason':'Operator has updated field evidence.'});assert ok.status_code==200 and ok.json()['status']=='OVERRIDDEN'
