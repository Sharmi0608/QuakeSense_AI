from robotics.astar import astar
from robotics.simulate import run_scenario

def valid(path,obstacles,width,height):
    blocked={tuple(p) for p in obstacles}
    assert path
    assert path[0]==[0,0]
    assert path[-1]==[width-1,height-1]
    assert not any(tuple(p) in blocked for p in path)
    for a,b in zip(path,path[1:]): assert abs(a[0]-b[0])+abs(a[1]-b[1])==1

def test_astar_simple():
    r=astar(5,5,[0,0],[4,4],[]); assert r['success']; assert r['path_length']==8; valid(r['path'],[],5,5)
def test_astar_avoids_obstacles():
    obs=[[1,0],[1,1],[1,2]];r=astar(5,5,[0,0],[4,4],obs);assert r['success'];valid(r['path'],obs,5,5)
def test_unreachable_and_blocked_goal():
    r=astar(3,3,[0,0],[2,2],[[1,0],[0,1]]);assert not r['success'] and r['path']==[]
    assert not astar(3,3,[0,0],[2,2],[[2,2]])['success']
def test_start_is_goal():
    r=astar(2,2,[1,1],[1,1],[]);assert r['success'] and r['path']==[[1,1]] and r['path_length']==0
def test_dynamic_replanning_is_real_and_valid():
    r=run_scenario(True);assert r['success'] and r['replan_count']==1;assert r['dynamic_obstacle'] in r['initial_path'];assert r['dynamic_obstacle'] not in r['final_path'];valid(r['final_path'],r['obstacles'],12,10)
