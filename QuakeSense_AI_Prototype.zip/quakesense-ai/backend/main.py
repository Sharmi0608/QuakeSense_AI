from __future__ import annotations
import json, os, time, uuid, math
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional
import httpx
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Float, Integer, DateTime, ForeignKey, Text, JSON, Boolean, UniqueConstraint, select, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session

ROOT = Path(__file__).resolve().parents[1]
DATABASE_URL = os.getenv('DATABASE_URL', f'sqlite:///{ROOT / "quakesense.db"}')
connect_args = {'check_same_thread': False} if DATABASE_URL.startswith('sqlite') else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
class Base(DeclarativeBase): pass
class Earthquake(Base):
    __tablename__='earthquake_events'; __table_args__=(UniqueConstraint('source','source_event_id'),)
    id: Mapped[int]=mapped_column(Integer,primary_key=True); source: Mapped[str]=mapped_column(String(30),default='USGS'); source_event_id: Mapped[str]=mapped_column(String(100)); magnitude: Mapped[float]=mapped_column(Float,default=0); place: Mapped[str]=mapped_column(String(300),default='Unknown'); depth_km: Mapped[Optional[float]]=mapped_column(Float,nullable=True); occurred_at: Mapped[datetime]=mapped_column(DateTime(timezone=True)); latitude: Mapped[float]=mapped_column(Float); longitude: Mapped[float]=mapped_column(Float); source_url: Mapped[Optional[str]]=mapped_column(String(500),nullable=True); raw_payload: Mapped[dict]=mapped_column(JSON,default=dict); imported_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Incident(Base):
    __tablename__='incidents'
    id: Mapped[int]=mapped_column(Integer,primary_key=True); earthquake_event_id: Mapped[Optional[int]]=mapped_column(ForeignKey('earthquake_events.id'),nullable=True); title: Mapped[str]=mapped_column(String(200)); description: Mapped[str]=mapped_column(Text,default=''); latitude: Mapped[float]=mapped_column(Float); longitude: Mapped[float]=mapped_column(Float); source_type: Mapped[str]=mapped_column(String(40),default='SIMULATED_SCENARIO'); severity: Mapped[int]=mapped_column(Integer,default=3); priority_score: Mapped[float]=mapped_column(Float,default=50); priority_band: Mapped[str]=mapped_column(String(20),default='Medium'); status: Mapped[str]=mapped_column(String(30),default='OPEN'); assessment_summary: Mapped[str]=mapped_column(Text,default='Pending assessment'); created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc)); updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Evidence(Base):
    __tablename__='evidence'; id: Mapped[int]=mapped_column(Integer,primary_key=True); incident_id: Mapped[int]=mapped_column(ForeignKey('incidents.id')); evidence_type: Mapped[str]=mapped_column(String(50)); source_type: Mapped[str]=mapped_column(String(50)); source_uri: Mapped[Optional[str]]=mapped_column(String(500),nullable=True); description: Mapped[str]=mapped_column(Text,default=''); confidence: Mapped[Optional[float]]=mapped_column(Float,nullable=True); metadata_json: Mapped[dict]=mapped_column(JSON,default=dict); created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Team(Base):
    __tablename__='response_teams'; id: Mapped[int]=mapped_column(Integer,primary_key=True); name: Mapped[str]=mapped_column(String(100)); team_type: Mapped[str]=mapped_column(String(60)); latitude: Mapped[float]=mapped_column(Float); longitude: Mapped[float]=mapped_column(Float); status: Mapped[str]=mapped_column(String(30),default='AVAILABLE'); capabilities_json: Mapped[dict]=mapped_column(JSON,default=dict); available_resources_json: Mapped[dict]=mapped_column(JSON,default=dict)
class RobotRun(Base):
    __tablename__='robot_runs'; id: Mapped[int]=mapped_column(Integer,primary_key=True); scenario_name: Mapped[str]=mapped_column(String(100)); algorithm: Mapped[str]=mapped_column(String(30),default='A*'); grid_configuration_json: Mapped[dict]=mapped_column(JSON); start_position_json: Mapped[dict]=mapped_column(JSON); goal_position_json: Mapped[dict]=mapped_column(JSON); initial_path_length: Mapped[Optional[int]]=mapped_column(Integer,nullable=True); final_path_length: Mapped[Optional[int]]=mapped_column(Integer,nullable=True); planning_runtime_ms: Mapped[Optional[float]]=mapped_column(Float,nullable=True); replan_count: Mapped[int]=mapped_column(Integer,default=0); success: Mapped[bool]=mapped_column(Boolean,default=False); evaluation_metrics_json: Mapped[dict]=mapped_column(JSON,default=dict); created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Recommendation(Base):
    __tablename__='recommendations'; id: Mapped[int]=mapped_column(Integer,primary_key=True); incident_id: Mapped[int]=mapped_column(ForeignKey('incidents.id')); team_id: Mapped[Optional[int]]=mapped_column(ForeignKey('response_teams.id'),nullable=True); mission_id: Mapped[Optional[int]]=mapped_column(Integer,nullable=True); priority_score: Mapped[float]=mapped_column(Float); recommended_action: Mapped[str]=mapped_column(Text); reasoning_json: Mapped[dict]=mapped_column(JSON,default=dict); status: Mapped[str]=mapped_column(String(30),default='PENDING'); override_reason: Mapped[Optional[str]]=mapped_column(Text,nullable=True); created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc)); updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc)); accepted_at: Mapped[Optional[datetime]]=mapped_column(DateTime(timezone=True),nullable=True); overridden_at: Mapped[Optional[datetime]]=mapped_column(DateTime(timezone=True),nullable=True)
class Mission(Base):
    __tablename__='missions'; id: Mapped[int]=mapped_column(Integer,primary_key=True); incident_id: Mapped[int]=mapped_column(ForeignKey('incidents.id')); team_id: Mapped[Optional[int]]=mapped_column(ForeignKey('response_teams.id'),nullable=True); status: Mapped[str]=mapped_column(String(30),default='ASSIGNED'); planned_route_json: Mapped[dict]=mapped_column(JSON,default=dict); path_length: Mapped[Optional[float]]=mapped_column(Float,nullable=True); planning_runtime_ms: Mapped[Optional[float]]=mapped_column(Float,nullable=True); assigned_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class DecisionEvent(Base):
    __tablename__='decision_events'; id: Mapped[int]=mapped_column(Integer,primary_key=True); incident_id: Mapped[Optional[int]]=mapped_column(ForeignKey('incidents.id'),nullable=True); recommendation_id: Mapped[Optional[int]]=mapped_column(ForeignKey('recommendations.id'),nullable=True); event_type: Mapped[str]=mapped_column(String(60)); actor_type: Mapped[str]=mapped_column(String(30),default='SYSTEM'); description: Mapped[str]=mapped_column(Text); event_payload_json: Mapped[dict]=mapped_column(JSON,default=dict); created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class Prediction(Base):
    __tablename__='damage_predictions'; id: Mapped[int]=mapped_column(Integer,primary_key=True); incident_id: Mapped[Optional[int]]=mapped_column(ForeignKey('incidents.id'),nullable=True); predicted_class: Mapped[str]=mapped_column(String(50)); class_probabilities: Mapped[dict]=mapped_column(JSON,default=dict); confidence: Mapped[float]=mapped_column(Float); prediction_source: Mapped[str]=mapped_column(String(50)); is_validated: Mapped[bool]=mapped_column(Boolean,default=False); created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class ModelRun(Base):
    __tablename__='model_runs'; id: Mapped[int]=mapped_column(Integer,primary_key=True); model_name: Mapped[str]=mapped_column(String(100)); model_version: Mapped[str]=mapped_column(String(60),default='untrained'); dataset_name: Mapped[str]=mapped_column(String(100),default='xBD/xView2 (not configured)'); checkpoint_path: Mapped[Optional[str]]=mapped_column(String(500),nullable=True); status: Mapped[str]=mapped_column(String(30),default='NOT_EVALUATED'); metrics_json: Mapped[dict]=mapped_column(JSON,default=dict); software_versions_json: Mapped[dict]=mapped_column(JSON,default=dict)
Base.metadata.create_all(engine)
def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()
def event(db, typ, desc, incident_id=None, recommendation_id=None, payload=None):
    db.add(DecisionEvent(incident_id=incident_id,recommendation_id=recommendation_id,event_type=typ,description=desc,event_payload_json=payload or {}))
def serialize(obj):
    out={c.name:getattr(obj,c.name) for c in obj.__table__.columns}
    for k,v in out.items():
        if isinstance(v,datetime): out[k]=v.isoformat()
    return out
app=FastAPI(title='QuakeSense AI API',version='0.1.0',description='Post-event disaster assessment and response-support prototype. Not an earthquake prediction system.')
app.add_middleware(CORSMiddleware,allow_origins=os.getenv('CORS_ORIGINS','http://localhost:5173,http://127.0.0.1:5173').split(','),allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
@app.on_event('startup')
def seed():
    with SessionLocal() as s:
        if s.query(Incident).count()==0:
            i=Incident(title='Demo: Riverside residential block',description='Seeded scenario for demonstrating evidence review and response prioritization. Not a verified real incident.',latitude=11.0168,longitude=76.9558,source_type='SIMULATED_SCENARIO',severity=4,priority_score=72,priority_band='High',assessment_summary='Simulated scenario; field verification required.')
            s.add(i); s.flush(); s.add(Evidence(incident_id=i.id,evidence_type='FIELD_REPORT',source_type='SIMULATED_SCENARIO',description='Demo report: visible facade damage reported; no casualty count supplied.',confidence=.65)); s.add_all([Team(name='Rescue Alpha',team_type='Urban Search & Rescue',latitude=11.0100,longitude=76.9500,status='AVAILABLE',capabilities_json={'search_rescue':True,'medical':True},available_resources_json={'members':6,'kits':2}),Team(name='Medical Bravo',team_type='Medical response',latitude=11.0250,longitude=76.9650,status='AVAILABLE',capabilities_json={'medical':True},available_resources_json={'members':4,'kits':3})]); event(s,'DEMO_SEEDED','Created clearly labeled demo incident and response teams.',i.id); s.commit()
@app.get('/api/health')
def health(db:Session=Depends(db)):
    try: db.execute(select(1)); database='connected'
    except Exception: database='unavailable'
    return {'status':'ok','database':database,'database_mode':'SQLite fallback' if DATABASE_URL.startswith('sqlite') else 'Configured SQL database','postgis':'not verified / not enabled by this schema','ml_checkpoint_available':any((ROOT/'models').glob('*.pt')),'robotics':'available','timestamp':datetime.now(timezone.utc).isoformat()}
@app.get('/api/dashboard')
def dashboard(db:Session=Depends(db)):
    incidents=db.query(Incident).order_by(Incident.priority_score.desc()).all(); events=db.query(Earthquake).order_by(Earthquake.occurred_at.desc()).limit(8).all(); recs=db.query(Recommendation).order_by(Recommendation.created_at.desc()).limit(5).all()
    return {'earthquake_count':db.query(Earthquake).count(),'incident_count':len(incidents),'open_incidents':sum(x.status=='OPEN' for x in incidents),'priority_distribution':{b:sum(x.priority_band==b for x in incidents) for b in ['Critical','High','Medium','Low']},'incidents':[serialize(x) for x in incidents],'earthquakes':[serialize(x) for x in events],'recommendations':[serialize(x) for x in recs],'teams':[serialize(x) for x in db.query(Team).all()],'robot_runs':[serialize(x) for x in db.query(RobotRun).order_by(RobotRun.created_at.desc()).limit(10).all()]}
@app.get('/api/earthquakes')
def earthquakes(limit:int=Query(100,ge=1,le=500),db:Session=Depends(db)): return [serialize(x) for x in db.query(Earthquake).order_by(Earthquake.occurred_at.desc()).limit(limit).all()]
@app.post('/api/ingestion/usgs/sync')
def sync_usgs(days:int=Query(7,ge=1,le=30),min_magnitude:float=Query(2.5,ge=0,le=10),limit:int=Query(100,ge=1,le=500),db:Session=Depends(db)):
    end=datetime.now(timezone.utc); start=end-timedelta(days=days); url='https://earthquake.usgs.gov/fdsnws/event/1/query'
    try:
        r=httpx.get(url,params={'format':'geojson','starttime':start.strftime('%Y-%m-%d'),'endtime':end.strftime('%Y-%m-%d'),'minmagnitude':min_magnitude,'limit':limit,'orderby':'time'},timeout=15); r.raise_for_status(); data=r.json()
    except Exception as e: raise HTTPException(502,detail=f'USGS sync failed; existing records preserved. {type(e).__name__}: {str(e)[:180]}')
    inserted=updated=0
    for f in data.get('features',[]):
        p=f.get('properties') or {}; coords=(f.get('geometry') or {}).get('coordinates') or []
        if len(coords)<3 or p.get('time') is None: continue
        sid=str(f.get('id') or '')
        if not sid: continue
        row=db.query(Earthquake).filter_by(source='USGS',source_event_id=sid).first()
        vals=dict(magnitude=float(p.get('mag') or 0),place=str(p.get('place') or 'Unknown'),depth_km=float(coords[2]) if coords[2] is not None else None,occurred_at=datetime.fromtimestamp(p['time']/1000,timezone.utc),latitude=float(coords[1]),longitude=float(coords[0]),source_url=p.get('url'),raw_payload=f)
        if row: 
            for k,v in vals.items(): setattr(row,k,v)
            updated+=1
        else: db.add(Earthquake(source='USGS',source_event_id=sid,**vals)); inserted+=1
    event(db,'USGS_SYNC',f'USGS sync fetched {len(data.get("features",[]))} features; inserted {inserted}, updated {updated}.',payload={'inserted':inserted,'updated':updated}); db.commit()
    return {'source':'USGS Earthquake Catalog','fetched':len(data.get('features',[])),'inserted':inserted,'updated':updated,'skipped':0,'failed':0,'synced_at':datetime.now(timezone.utc).isoformat()}
@app.get('/api/incidents')
def incidents(db:Session=Depends(db)): return [serialize(x) for x in db.query(Incident).order_by(Incident.priority_score.desc()).all()]
class IncidentIn(BaseModel): title:str=Field(min_length=3,max_length=200); description:str=''; latitude:float=Field(ge=-90,le=90); longitude:float=Field(ge=-180,le=180); source_type:str='OPERATOR_INPUT'; severity:int=Field(default=3,ge=1,le=5)
@app.post('/api/incidents')
def create_incident(body:IncidentIn,db:Session=Depends(db)):
    score=round(body.severity*15+10,1); band='Critical' if score>=80 else 'High' if score>=60 else 'Medium' if score>=35 else 'Low'; i=Incident(**body.model_dump(),priority_score=score,priority_band=band,assessment_summary='Initial rule-based assessment; requires human verification.'); db.add(i); db.flush(); event(db,'INCIDENT_CREATED','Incident created with rule-based initial assessment.',i.id); db.commit(); db.refresh(i); return serialize(i)
@app.get('/api/incidents/{incident_id}')
def incident_detail(incident_id:int,db:Session=Depends(db)):
    i=db.get(Incident,incident_id)
    if not i: raise HTTPException(404,'Incident not found')
    return {**serialize(i),'evidence':[serialize(x) for x in db.query(Evidence).filter_by(incident_id=i.id).all()],'predictions':[serialize(x) for x in db.query(Prediction).filter_by(incident_id=i.id).all()],'recommendations':[serialize(x) for x in db.query(Recommendation).filter_by(incident_id=i.id).all()]}
class EvidenceIn(BaseModel): evidence_type:str='FIELD_REPORT'; source_type:str='OPERATOR_INPUT'; description:str=Field(min_length=3,max_length=3000); source_uri:Optional[str]=None; confidence:Optional[float]=Field(default=None,ge=0,le=1)
@app.post('/api/incidents/{incident_id}/evidence')
def add_evidence(incident_id:int,body:EvidenceIn,db:Session=Depends(db)):
    i=db.get(Incident,incident_id)
    if not i: raise HTTPException(404,'Incident not found')
    e=Evidence(incident_id=incident_id,**body.model_dump()); db.add(e); event(db,'EVIDENCE_ADDED','New evidence added; reassessment is available.',incident_id,payload={'source_type':body.source_type}); db.commit(); db.refresh(e); return serialize(e)
@app.post('/api/incidents/{incident_id}/reassess')
def reassess(incident_id:int,db:Session=Depends(db)):
    i=db.get(Incident,incident_id)
    if not i: raise HTTPException(404,'Incident not found')
    ev=db.query(Evidence).filter_by(incident_id=incident_id).all(); valid_preds=db.query(Prediction).filter_by(incident_id=incident_id,prediction_source='TRAINED_MODEL').all(); old=i.priority_score
    score=min(100, max(0, i.severity*13 + min(20,len(ev)*5) + (10 if any(p.predicted_class in ('major-damage','destroyed') for p in valid_preds) else 0)))
    i.priority_score=round(score,1); i.priority_band='Critical' if score>=80 else 'High' if score>=60 else 'Medium' if score>=35 else 'Low'; i.assessment_summary=f'Rule-based reassessment using {len(ev)} evidence item(s) and {len(valid_preds)} trained-model prediction(s). Human review required.'; i.updated_at=datetime.now(timezone.utc); event(db,'INCIDENT_REASSESSED','Priority recalculated from available evidence; missing evidence is not treated as proof of safety.',incident_id,payload={'previous_score':old,'new_score':i.priority_score,'evidence_count':len(ev)}); db.commit(); return {'incident':serialize(i),'previous_score':old,'new_score':i.priority_score,'factors':['Severity input','Evidence count','Validated trained-model output if available'],'uncertainties':['No verified casualty data','Image damage classification is not a structural safety inspection']}
@app.get('/api/recommendations')
def recommendations(db:Session=Depends(db)): return [serialize(x) for x in db.query(Recommendation).order_by(Recommendation.created_at.desc()).all()]
@app.post('/api/incidents/{incident_id}/recommendations')
def make_recommendation(incident_id:int,db:Session=Depends(db)):
    i=db.get(Incident,incident_id)
    if not i: raise HTTPException(404,'Incident not found')
    team=db.query(Team).filter_by(status='AVAILABLE').first(); route_note='route planning must be checked in Robotics Lab'; action='Prioritize field verification and dispatch-capable team for human review' if i.priority_score>=60 else 'Gather additional evidence and maintain monitoring'; reasons={'priority_score':i.priority_score,'priority_band':i.priority_band,'incident_source':i.source_type,'evidence_count':db.query(Evidence).filter_by(incident_id=i.id).count(),'team_candidate':team.name if team else None,'route_status':route_note,'method':'deterministic rule-based; not autonomous dispatch'}
    r=Recommendation(incident_id=i.id,team_id=team.id if team else None,priority_score=i.priority_score,recommended_action=action,reasoning_json=reasons); db.add(r); db.flush(); event(db,'RECOMMENDATION_CREATED','Recommendation generated for operator review.',i.id,r.id,reasons); db.commit(); db.refresh(r); return serialize(r)
@app.post('/api/recommendations/{rid}/accept')
def accept(rid:int,db:Session=Depends(db)):
    r=db.get(Recommendation,rid)
    if not r: raise HTTPException(404,'Recommendation not found')
    if r.status=='ACCEPTED': return {'recommendation':serialize(r),'mission':serialize(db.get(Mission,r.mission_id)) if r.mission_id else None,'idempotent':True}
    if r.status!='PENDING': raise HTTPException(409,f'Cannot accept recommendation in {r.status} state')
    try:
        r.status='ACCEPTED'; r.accepted_at=datetime.now(timezone.utc); r.updated_at=r.accepted_at
        m=Mission(incident_id=r.incident_id,team_id=r.team_id,status='ASSIGNED',planned_route_json={'planner':'A* available in Robotics Lab','status':'route not yet attached'},path_length=None); db.add(m); db.flush(); r.mission_id=m.id; event(db,'RECOMMENDATION_ACCEPTED','Operator accepted recommendation; mission record assigned (route planning remains separate).',r.incident_id,r.id,{'mission_id':m.id}); db.commit(); db.refresh(r); db.refresh(m); return {'recommendation':serialize(r),'mission':serialize(m),'idempotent':False}
    except Exception: db.rollback(); raise HTTPException(500,'Acceptance transaction failed; no changes committed')
class OverrideIn(BaseModel): reason:str=Field(min_length=5,max_length=1000)
@app.post('/api/recommendations/{rid}/override')
def override(rid:int,body:OverrideIn,db:Session=Depends(db)):
    r=db.get(Recommendation,rid)
    if not r: raise HTTPException(404,'Recommendation not found')
    if r.status!='PENDING': raise HTTPException(409,f'Cannot override recommendation in {r.status} state')
    r.status='OVERRIDDEN'; r.override_reason=body.reason; r.overridden_at=datetime.now(timezone.utc); r.updated_at=r.overridden_at; event(db,'RECOMMENDATION_OVERRIDDEN','Operator overrode recommendation; original reasoning preserved.',r.incident_id,r.id,{'reason':body.reason}); db.commit(); db.refresh(r); return serialize(r)
@app.get('/api/events')
def events(limit:int=Query(100,ge=1,le=500),db:Session=Depends(db)): return [serialize(x) for x in db.query(DecisionEvent).order_by(DecisionEvent.created_at.desc()).limit(limit).all()]
@app.get('/api/teams')
def teams(db:Session=Depends(db)): return [serialize(x) for x in db.query(Team).all()]
@app.get('/api/models')
def models(db:Session=Depends(db)):
    runs=[serialize(x) for x in db.query(ModelRun).all()]
    if not runs: return [{'id':None,'model_name':'ResNet-18 transfer learning','model_version':'not-trained','dataset_name':'xBD/xView2 (not configured)','checkpoint_path':None,'status':'NOT_EVALUATED','metrics_json':{},'note':'No saved experiment record or checkpoint found.'}]
    return runs
@app.get('/api/cv/predictions')
def predictions(db:Session=Depends(db)): return [serialize(x) for x in db.query(Prediction).order_by(Prediction.created_at.desc()).limit(50).all()]
@app.get('/api/models/{model_id}/metrics')
def model_metrics(model_id:int,db:Session=Depends(db)):
    row=db.get(ModelRun,model_id)
    if not row: raise HTTPException(404,'Model run not found')
    return {'id':row.id,'status':row.status,'metrics':row.metrics_json,'model_name':row.model_name,'checkpoint_path':row.checkpoint_path}
@app.post('/api/cv/predict')
async def cv_predict(file:UploadFile=File(...),incident_id:Optional[int]=None,db:Session=Depends(db)):
    if file.content_type not in ('image/jpeg','image/png','image/webp'): raise HTTPException(415,'Upload a JPEG, PNG, or WebP image.')
    data=await file.read()
    if len(data)>8*1024*1024: raise HTTPException(413,'Image must be 8 MB or smaller.')
    checkpoints=list((ROOT/'models').glob('*.pt'))
    if not checkpoints: return {'status':'model_not_available','prediction_source':'NONE','message':'No trained checkpoint is installed. No prediction was fabricated. Add a checkpoint after running the documented training workflow.'}
    try:
        from ml.cv.inference import predict_image
        result=predict_image(data,checkpoints[0])
    except Exception as e: raise HTTPException(503,f'Checkpoint inference unavailable: {type(e).__name__}: {str(e)[:120]}')
    p=Prediction(incident_id=incident_id,predicted_class=result['predicted_class'],class_probabilities=result['probabilities'],confidence=result['confidence'],prediction_source='TRAINED_MODEL'); db.add(p); event(db,'MODEL_PREDICTION','Image processed using saved model checkpoint.',incident_id,payload={'prediction_id':None,'model':str(checkpoints[0].name)}); db.commit(); db.refresh(p); return {'status':'ok',**serialize(p),'model_version':checkpoints[0].name,'checkpoint_reference':str(checkpoints[0].relative_to(ROOT))}
# robotics API uses deterministic grid state stored in JSON file for simple demo; run metrics persist in DB
from robotics.simulate import run_scenario
@app.post('/api/robotics/scenarios')
def create_robot_scenario(): return {'id':'demo-grid','scenario_name':'Demo grid-world','width':12,'height':10,'start':[0,0],'goal':[11,9],'obstacles':[[3,0],[3,1],[3,2],[6,4],[6,5],[6,6],[8,7]],'source_type':'SIMULATED_SCENARIO'}
@app.get('/api/robotics/scenarios/{scenario_id}')
def get_robot_scenario(scenario_id:str):
    if scenario_id!='demo-grid': raise HTTPException(404,'Scenario not found')
    return {'id':scenario_id,'width':12,'height':10,'start':[0,0],'goal':[11,9],'obstacles':[[3,0],[3,1],[3,2],[6,4],[6,5],[6,6],[8,7]]}
@app.post('/api/robotics/scenarios/{scenario_id}/plan')
def plan_robot(scenario_id:str,db:Session=Depends(db)):
    if scenario_id!='demo-grid': raise HTTPException(404,'Scenario not found')
    result=run_scenario(dynamic=True); row=RobotRun(scenario_name='Demo grid-world dynamic replanning',algorithm='A*',grid_configuration_json={'width':12,'height':10,'dynamic_obstacle':result['dynamic_obstacle']},start_position_json={'x':0,'y':0},goal_position_json={'x':11,'y':9},initial_path_length=result['initial_path_length'],final_path_length=result['final_path_length'],planning_runtime_ms=result['planning_runtime_ms'],replan_count=result['replan_count'],success=result['success'],evaluation_metrics_json=result); db.add(row); event(db,'ROBOTICS_RUN','A* path planned and dynamic replanning executed.',payload={'success':result['success'],'replan_count':result['replan_count']}); db.commit(); db.refresh(row); return {'run_id':row.id,**result}
@app.post('/api/robotics/scenarios/{scenario_id}/step')
def step_robot(scenario_id:str):
    if scenario_id!='demo-grid': raise HTTPException(404,'Scenario not found')
    return {'status':'step_ready','message':'Run a fresh A* scenario to generate an actual route; step-wise animation is a frontend visualization feature in this MVP.'}
@app.post('/api/robotics/scenarios/{scenario_id}/introduce-obstacle')
def introduce_obstacle(scenario_id:str):
    if scenario_id!='demo-grid': raise HTTPException(404,'Scenario not found')
    return {'status':'obstacle_scenario_available','message':'The plan endpoint executes a deterministic obstacle insertion and replanning run.'}
@app.get('/api/robotics/runs')
def robot_runs(db:Session=Depends(db)): return [serialize(x) for x in db.query(RobotRun).order_by(RobotRun.created_at.desc()).limit(30).all()]
