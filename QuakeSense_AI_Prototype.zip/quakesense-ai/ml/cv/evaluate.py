"""Evaluate saved checkpoint on a held-out test.csv manifest."""
import argparse,csv,json,time
from pathlib import Path
import torch
from sklearn.metrics import accuracy_score,balanced_accuracy_score,classification_report,confusion_matrix,f1_score
from torch.utils.data import DataLoader
from .train import ManifestDataset
from .inference import load_checkpoint

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest-dir',default='data/manifests');p.add_argument('--checkpoint',default='models/quakesense_resnet18.pt');p.add_argument('--out',default='ml/experiments/latest_metrics.json');p.add_argument('--batch-size',type=int,default=16);a=p.parse_args();model,labels,tf,device,ck=load_checkpoint(a.checkpoint);rows=list(csv.DictReader(open(Path(a.manifest_dir)/'test.csv',encoding='utf-8-sig')))
 if not rows:raise SystemExit('test.csv is empty; no evaluation performed.')
 ds=ManifestDataset(Path(a.manifest_dir)/'test.csv',{x:i for i,x in enumerate(labels)},int(ck.get('image_size',224)));loader=DataLoader(ds,batch_size=a.batch_size);ys=[];ps=[];start=time.perf_counter();model.eval()
 with torch.no_grad():
  for x,y in loader:ps.extend(model(x.to(device)).argmax(1).cpu().tolist());ys.extend(y.tolist())
 latency=(time.perf_counter()-start)*1000/max(1,len(ys));report=classification_report(ys,ps,labels=list(range(len(labels))),target_names=labels,output_dict=True,zero_division=0);train_rows=list(csv.DictReader(open(Path(a.manifest_dir)/'train.csv',encoding='utf-8-sig'))); train_labels=[r['label'] for r in train_rows]; majority=max(set(train_labels),key=train_labels.count) if train_labels else None; majority_idx=labels.index(majority) if majority in labels else None; baseline_accuracy=sum(1 for y in ys if y==majority_idx)/len(ys) if majority_idx is not None and ys else None
 metrics={'checkpoint':str(Path(a.checkpoint)),'dataset_manifest':str(Path(a.manifest_dir)/'test.csv'),'sample_count':len(ys),'labels':labels,'majority_class_baseline':{'class':majority,'accuracy':baseline_accuracy},'accuracy':accuracy_score(ys,ps),'balanced_accuracy':balanced_accuracy_score(ys,ps),'macro_f1':f1_score(ys,ps,average='macro',zero_division=0),'per_class':{k:v for k,v in report.items() if k in labels},'confusion_matrix':confusion_matrix(ys,ps,labels=list(range(len(labels)))).tolist(),'mean_inference_latency_ms_per_image':latency,'status':'EVALUATED'};out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2))
if __name__=='__main__':main()
