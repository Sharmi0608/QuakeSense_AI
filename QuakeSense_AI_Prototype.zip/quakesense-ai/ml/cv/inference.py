import io,torch
from torch import nn
from torchvision import models,transforms
from PIL import Image

def load_checkpoint(path,device=None):
 device=device or ('cuda' if torch.cuda.is_available() else 'cpu'); ck=torch.load(path,map_location=device,weights_only=False); labels=ck['labels']; model=models.resnet18(weights=None);model.fc=nn.Linear(model.fc.in_features,len(labels));model.load_state_dict(ck['state_dict']);model.eval().to(device); size=int(ck.get('image_size',224)); tf=transforms.Compose([transforms.Resize((size,size)),transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])]);return model,labels,tf,device,ck

def predict_image(data,checkpoint):
 model,labels,tf,device,ck=load_checkpoint(checkpoint)
 with Image.open(io.BytesIO(data)) as im: x=tf(im.convert('RGB')).unsqueeze(0).to(device)
 with torch.no_grad(): probs=torch.softmax(model(x),dim=1)[0].cpu().tolist()
 idx=max(range(len(probs)),key=probs.__getitem__);return {'predicted_class':labels[idx],'probabilities':{label:round(float(prob),6) for label,prob in zip(labels,probs)},'confidence':float(probs[idx]),'model_version':ck.get('trained_at','unknown')}
