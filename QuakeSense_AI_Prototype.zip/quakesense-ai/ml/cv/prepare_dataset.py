"""Create group-aware train/validation/test manifests from a curated CSV.
Input CSV columns: image_path,label,group. Paths must point to real images and labels.
"""
import argparse,csv,random
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True,help='Curated CSV with image_path,label,group');p.add_argument('--out-dir',default='data/manifests');p.add_argument('--seed',type=int,default=42);a=p.parse_args(); random.seed(a.seed)
 rows=list(csv.DictReader(open(a.input,encoding='utf-8-sig')))
 if not rows or not {'image_path','label','group'}<=set(rows[0]): raise SystemExit('CSV requires image_path,label,group columns.')
 groups={}
 for r in rows:
  if not Path(r['image_path']).is_file(): raise SystemExit(f"Missing image: {r['image_path']}")
  if not r['label'].strip() or not r['group'].strip(): raise SystemExit('Empty label/group found; do not invent labels.')
  groups.setdefault(r['group'],[]).append(r)
 keys=list(groups); random.shuffle(keys)
 if len(keys)<3: raise SystemExit('Need at least 3 distinct groups for group-aware train/val/test splits.')
 n=len(keys); ntest=max(1,round(n*.15)); nval=max(1,round(n*.15)); test=set(keys[:ntest]); val=set(keys[ntest:ntest+nval]); train=set(keys[ntest+nval:])
 if not train: train={keys[-1]}; val.discard(keys[-1])
 out=Path(a.out_dir);out.mkdir(parents=True,exist_ok=True)
 for name,sel in [('train',train),('val',val),('test',test)]:
  with (out/f'{name}.csv').open('w',newline='',encoding='utf-8') as f:
   w=csv.DictWriter(f,fieldnames=['image_path','label','group']);w.writeheader();w.writerows(r for g in sorted(sel) for r in groups[g])
 print(f'Groups: {len(groups)} | train={len(train)} val={len(val)} test={len(test)}. Group splits saved to {out.resolve()}')
if __name__=='__main__':main()
