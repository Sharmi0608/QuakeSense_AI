"""Train a ResNet-18 classifier from train.csv and val.csv manifests."""
import argparse,csv,json,random,time,platform
from pathlib import Path
import torch
from torch import nn
from torch.utils.data import Dataset,DataLoader
from torchvision import models,transforms
from PIL import Image
class ManifestDataset(Dataset):
 def __init__(self,path,labels,size=224,train=False):
  self.rows=list(csv.DictReader(open(path,encoding='utf-8-sig')));self.labels=labels
  ops=[transforms.Resize((size,size))]
  if train: ops += [transforms.RandomHorizontalFlip(),transforms.RandomRotation(8)]
  ops += [transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])];self.tf=transforms.Compose(ops)
 def __len__(self):return len(self.rows)
 def __getitem__(self,i):
  r=self.rows[i]
  with Image.open(r['image_path']) as im: x=self.tf(im.convert('RGB'))
  return x,self.labels[r['label']]
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest-dir',default='data/manifests');p.add_argument('--out',default='models/quakesense_resnet18.pt');p.add_argument('--epochs',type=int,default=3);p.add_argument('--batch-size',type=int,default=16);p.add_argument('--lr',type=float,default=.0003);p.add_argument('--image-size',type=int,default=224);p.add_argument('--seed',type=int,default=42);p.add_argument('--pretrained',action='store_true');a=p.parse_args()
 random.seed(a.seed);torch.manual_seed(a.seed);torch.cuda.manual_seed_all(a.seed);base=Path(a.manifest_dir);tr=list(csv.DictReader(open(base/'train.csv',encoding='utf-8-sig')));va=list(csv.DictReader(open(base/'val.csv',encoding='utf-8-sig')));labels=sorted({r['label'] for r in tr});
 if len(labels)<2:raise SystemExit('Training requires at least two real label classes in train.csv.')
 if not va:raise SystemExit('Validation manifest is empty.')
 dev='cuda' if torch.cuda.is_available() else 'cpu'; ds=ManifestDataset(base/'train.csv',{x:i for i,x in enumerate(labels)},a.image_size,True);vd=ManifestDataset(base/'val.csv',{x:i for i,x in enumerate(labels)},a.image_size);tl=DataLoader(ds,batch_size=a.batch_size,shuffle=True);vl=DataLoader(vd,batch_size=a.batch_size)
 weights=models.ResNet18_Weights.DEFAULT if a.pretrained else None
 try: model=models.resnet18(weights=weights)
 except Exception as e:
  if a.pretrained: print(f'Pretrained weights unavailable ({e}); using random initialization.');model=models.resnet18(weights=None)
 model.fc=nn.Linear(model.fc.in_features,len(labels));model.to(dev);opt=torch.optim.AdamW(model.parameters(),lr=a.lr);loss_fn=nn.CrossEntropyLoss();started=time.time();best=float('inf')
 for epoch in range(a.epochs):
  model.train();sumloss=0
  for x,y in tl:x,y=x.to(dev),y.to(dev);opt.zero_grad();loss=loss_fn(model(x),y);loss.backward();opt.step();sumloss+=loss.item()*len(y)
  model.eval();vsum=0
  with torch.no_grad():
   for x,y in vl:x,y=x.to(dev),y.to(dev);vsum+=loss_fn(model(x),y).item()*len(y)
  vloss=vsum/len(vd);print(f'epoch {epoch+1}/{a.epochs} train_loss={sumloss/len(ds):.4f} val_loss={vloss:.4f}')
  if vloss<best:best=vloss;out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);torch.save({'state_dict':model.state_dict(),'labels':labels,'image_size':a.image_size,'architecture':'resnet18','seed':a.seed,'validation_loss':best,'epochs':a.epochs,'trained_at':time.time(),'software':{'python':platform.python_version(),'torch':torch.__version__}},out)
 print(f'Checkpoint saved: {Path(a.out).resolve()} | device={dev} | duration={time.time()-started:.1f}s | validation loss={best:.4f}. Run evaluation separately on test.csv.')
if __name__=='__main__':main()
