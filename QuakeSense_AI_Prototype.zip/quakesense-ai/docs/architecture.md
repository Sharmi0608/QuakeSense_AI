# QuakeSense AI architecture and academic mapping

```mermaid
flowchart LR
  USGS[USGS Catalog API] --> ING[Ingestion + provenance]
  OP[Operator / field evidence] --> API[FastAPI services]
  ING --> DB[(SQLAlchemy database)]
  API --> DB
  IMG[Disaster image] --> CV[PyTorch CV inference]
  CV --> DB
  DB --> DEC[Deterministic assessment engine]
  DEC --> REC[Human-reviewed recommendation]
  REC --> AUD[Decision audit events]
  ROB[A* grid-world + dynamic replanning] --> DB
  DEC --> UI[React Command Center]
  DB --> UI
  UI --> HUMAN[Operator accept / override]
  HUMAN --> AUD
```

## Academic contribution

- **Intelligent Robotics:** grid-world state representation, four-connected neighbors, Manhattan heuristic, A* search, route validation, dynamic obstacle injection, genuine replanning, expanded-node and runtime metrics.
- **Foundations of Computer Vision:** RGB image loading, resize/normalization, optional augmentation, ResNet-18 classification, saved-checkpoint inference, per-class probabilities and confusion matrix.
- **Machine Learning Techniques:** reproducible seed, event/group-aware manifests, transfer learning option, validation selection, held-out test evaluation, baseline status explicitly not populated until measured.
- **Software engineering / geospatial:** FastAPI endpoints, SQLAlchemy relational persistence, source labels, audit history, coordinates and USGS source links. Full PostGIS geometry/indexing and Alembic migrations remain implementation work, and must not be described as already active.

## Trust boundaries

`REAL_SOURCE_DATA` is reserved for imported source records. `SIMULATED_SCENARIO` is used for the seed incident and grid-world. `OPERATOR_INPUT` labels operator-entered content. Model output is stored as `TRAINED_MODEL` only when inference actually ran against a checkpoint. Rule-based assessments are deterministic and should be reviewed by humans.
