# QuakeSense AI — Disaster Intelligence Prototype

**Purpose:** a post-earthquake assessment and response-support prototype that links earthquake catalog ingestion, incident evidence, transparent rule-based prioritization, a human-reviewed recommendation workflow, computer-vision experiment tooling, and an A* grid-world robotics simulation. It does **not** predict earthquakes, automatically dispatch real responders, or certify structural safety.

## What is included

- FastAPI API with OpenAPI/Swagger docs and SQLAlchemy persistence.
- SQLite fallback for a quick local demo; configurable PostgreSQL connection. A PostGIS Docker service definition is included, but this MVP schema currently stores coordinates as numeric columns and **does not implement PostGIS geometry columns or GiST indexes**.
- Idempotent USGS GeoJSON ingestion with bounded time/magnitude/result settings, request timeout, and preservation of prior records on failure.
- Incident/evidence records, deterministic reassessment, recommendations, accept/override endpoints, mission records, and an audit timeline.
- A* path planner with a true dynamic obstacle selected from the computed route, a second A* run, measured runtime, and persistent run metrics.
- PyTorch/torchvision ResNet-18 training, group-aware manifest preparation, held-out evaluation, and checkpoint inference scripts. No checkpoint or xBD dataset is bundled. CV endpoint reports unavailable when there is no checkpoint.
- React/TypeScript/Vite command-center UI with incident queue, earthquake catalog, CV Lab, ML experiment status, Robotics Lab, team view, decision timeline, and system health.
- Automated tests for A*, replanning, API health, recommendation acceptance idempotency, and override validation.

## Prerequisites

- Python 3.10+ (3.11 recommended)
- Node.js 20+ and npm
- Optional: PostgreSQL. Optional GPU training requires a PyTorch build matching your installed NVIDIA CUDA driver/toolkit; use the official PyTorch selector.

## Quick start — Windows PowerShell

From the project root:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Open a second PowerShell window:

```powershell
cd frontend
npm install
npm run dev
```

URLs:
- Frontend: http://localhost:5173
- Swagger API docs: http://127.0.0.1:8000/docs
- Health check: http://127.0.0.1:8000/api/health

The backend seeds a clearly labeled **SIMULATED_SCENARIO** incident and response teams on first startup. It does not reset the database on refresh. Default SQLite file is `quakesense.db` in the project root. To use a direct Python invocation if PowerShell activation is restricted, run `..\.venv\Scripts\python.exe -m pip install -r ..\requirements.txt` from the frontend directory, or invoke the venv Python by absolute path.

## USGS data

Click **Sync USGS** on Live Earthquakes or call:

```powershell
Invoke-RestMethod -Method Post "http://127.0.0.1:8000/api/ingestion/usgs/sync?days=7&min_magnitude=2.5&limit=100"
```

The API uses the official USGS Earthquake Catalog endpoint and deduplicates by `(source, source_event_id)`. The internet must be available. A failed sync returns HTTP 502 and leaves existing imported rows intact. No successful live synchronization is claimed until you run it and receive a success summary.

## Robotics demonstration

In Robotics Lab, click **Run & replan**. The backend finds an A* route in a 12×10 grid, chooses a cell from that computed route, marks it blocked, and calls A* again. It returns both paths and runtime/expanded-node metrics and stores the run. This is a grid-world simulation only, not a physical robot integration.

## Computer vision and ML experiment workflow

The app can run without xBD data or a checkpoint. xBD/xView2 access, dataset license terms, and source labels must be checked at https://xview2.org/ before acquisition. The project intentionally does not automatically download large datasets or include them in the ZIP.

Create a curated CSV with real, verified labels and groups (e.g. disaster-event IDs), using these exact columns:

```csv
image_path,label,group
D:/xbd/crops/example_a.png,no-damage,event_001
D:/xbd/crops/example_b.png,minor-damage,event_002
```

Use at least three distinct groups; this simple splitter is for a small research prototype and should be reviewed for class stratification and event balance before formal evaluation.

```powershell
python -m ml.cv.prepare_dataset --input data/my_curated_images.csv --out-dir data/manifests --seed 42
python -m ml.cv.train --manifest-dir data/manifests --epochs 3 --batch-size 16 --pretrained --out models/quakesense_resnet18.pt
python -m ml.cv.evaluate --manifest-dir data/manifests --checkpoint models/quakesense_resnet18.pt --out ml/experiments/latest_metrics.json
```

`--pretrained` may need internet access for torchvision weights; omit it for random initialization. The label names in manifests are preserved exactly and are **not** automatically mapped to xBD labels. Do not evaluate until the test manifest contains appropriate held-out real samples. Training/evaluation outputs are only evidence for the dataset and run that actually completed. Install ML dependencies only when you are ready to train/infer: first select a compatible PyTorch build at https://pytorch.org/get-started/locally/, then install the remaining packages in `requirements-ml.txt` (omit/reconcile the torch lines if you installed a CUDA-specific wheel).

## Database configuration

Default `.env.example` points to SQLite for the simplest demo. For PostgreSQL, install the driver `pip install "psycopg[binary]"`, start a PostgreSQL database, and set `DATABASE_URL` to e.g. `postgresql+psycopg://quakesense:CHANGE_ME@localhost:5432/quakesense`. Environment loading is left to your shell/runtime; export the variables or install `python-dotenv` and load it in your environment. Optional Docker database:

```powershell
docker compose up -d db
```

Set a non-default `POSTGRES_PASSWORD` before use. **Important limitations:** this prototype uses `Base.metadata.create_all()` for quick local startup rather than Alembic migrations, and it does not yet activate PostGIS geometry storage/indexes despite the optional PostGIS container. For production or assessed geospatial persistence, implement and apply Alembic migrations, GeoAlchemy2 geometry fields, SRID 4326, and GiST indexes before claiming PostGIS support.

## Tests

```powershell
pip install -r requirements.txt
python -m pytest -q
```

The API tests use the local configured database. For clean repeatable testing, set `DATABASE_URL=sqlite:///./test_quakesense.db` before running. Test outcomes must be reported from your own environment. The ML scripts additionally require `requirements-ml.txt` and a compatible PyTorch/torchvision installation; the evaluation script also uses scikit-learn.

## API overview

- `GET /api/health`, `GET /api/dashboard`
- `GET /api/earthquakes`, `POST /api/ingestion/usgs/sync`
- `GET /api/incidents`, `POST /api/incidents`, `GET /api/incidents/{id}`
- `POST /api/incidents/{id}/evidence`, `POST /api/incidents/{id}/reassess`
- `POST /api/incidents/{id}/recommendations`, `GET /api/recommendations`
- `POST /api/recommendations/{id}/accept`, `POST /api/recommendations/{id}/override`
- `GET /api/events`, `GET /api/teams`
- `POST /api/cv/predict`, `GET /api/cv/predictions`, `GET /api/models`
- `POST /api/robotics/scenarios`, `GET /api/robotics/scenarios/{id}`, `POST /api/robotics/scenarios/{id}/plan`, `POST /api/robotics/scenarios/{id}/step`, `POST /api/robotics/scenarios/{id}/introduce-obstacle`, `GET /api/robotics/runs`

## Five-minute demonstration script

1. **Command Center (30 sec):** identify the seeded incident as simulated and explain the rule-based priority score.
2. **Live Earthquakes (45 sec):** click Sync USGS and show imported catalog records and their source links. If the network is blocked, state that live sync was unavailable; do not present simulated events as USGS records.
3. **Incident assessment (45 sec):** inspect evidence, click Reassess, and discuss score changes and missing/uncertain evidence.
4. **Robotics Lab (60 sec):** run A*, show initial path, dynamically blocked route cell, recalculated path, route lengths, expanded nodes and runtime.
5. **Recommendation (60 sec):** generate a recommendation and explain its rule-based factors; accept it or override it with a meaningful reason.
6. **Audit + persistence (30 sec):** refresh, show the stored status, mission and event timeline.
7. **CV/ML (30 sec):** show honest checkpoint/dataset status. Only demonstrate inference or performance if a real trained checkpoint and actual held-out evaluation exist.

## Known limitations and safety

This is an academic prototype, not an emergency-services product. PostGIS geometry and Alembic migrations are pending; SQLite is the verified quick-start target until tested. Robotics has a working planner and batch dynamic replanning but the `/step` endpoint is a placeholder response and the UI does not animate individual robot steps. The CV workflow depends on external dataset access, correctly curated labels, and actual training. The system does not estimate casualties, predict earthquakes, determine structural safety, or dispatch resources. Qualified responders must independently validate any operational decision.
