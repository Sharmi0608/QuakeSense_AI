from heapq import heappush, heappop
from time import perf_counter

def astar(width, height, start, goal, obstacles):
    blocked=set(tuple(p) for p in obstacles); start=tuple(start); goal=tuple(goal)
    if start in blocked or goal in blocked: return {'path':[],'success':False,'runtime_ms':0.0,'expanded_nodes':0}
    t=perf_counter(); frontier=[]; heappush(frontier,(0,start)); came={}; cost={start:0}; expanded=0
    while frontier:
        _,cur=heappop(frontier); expanded+=1
        if cur==goal: break
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
            nxt=(cur[0]+dx,cur[1]+dy)
            if not (0<=nxt[0]<width and 0<=nxt[1]<height) or nxt in blocked: continue
            nc=cost[cur]+1
            if nc<cost.get(nxt,float('inf')):
                cost[nxt]=nc; came[nxt]=cur; h=abs(goal[0]-nxt[0])+abs(goal[1]-nxt[1]); heappush(frontier,(nc+h,nxt))
    elapsed=(perf_counter()-t)*1000
    if goal not in cost: return {'path':[],'success':False,'runtime_ms':elapsed,'expanded_nodes':expanded}
    path=[goal]
    while path[-1]!=start: path.append(came[path[-1]])
    path.reverse(); return {'path':[list(p) for p in path],'success':True,'runtime_ms':elapsed,'expanded_nodes':expanded,'path_length':len(path)-1,'path_cost':cost[goal]}
