from .astar import astar

def run_scenario(dynamic=True):
    width,height=12,10; start=[0,0]; goal=[11,9]; obstacles=[[3,0],[3,1],[3,2],[6,4],[6,5],[6,6],[8,7]]
    first=astar(width,height,start,goal,obstacles)
    if not first['success']: return {'success':False,'initial_path_length':None,'final_path_length':None,'replan_count':0,'initial_path':[],'final_path':[],'planning_runtime_ms':first['runtime_ms'],'obstacles':obstacles,'dynamic_obstacle':None}
    final=first; replan=0; dynamic_obstacle=None
    if dynamic and len(first['path'])>5:
        # Block a cell on the actual initial path, not a preset route.
        dynamic_obstacle=first['path'][len(first['path'])//2]
        new_obstacles=obstacles+[dynamic_obstacle]
        final=astar(width,height,start,goal,new_obstacles); replan=1
        obstacles=new_obstacles
    return {'success':final['success'],'initial_path_length':first.get('path_length'),'final_path_length':final.get('path_length'),'replan_count':replan,'initial_path':first['path'],'final_path':final['path'],'planning_runtime_ms':round(first['runtime_ms']+final['runtime_ms'],3),'initial_runtime_ms':round(first['runtime_ms'],3),'replan_runtime_ms':round(final['runtime_ms'],3) if replan else 0,'expanded_nodes':first['expanded_nodes']+final['expanded_nodes'],'obstacles':obstacles,'dynamic_obstacle':dynamic_obstacle,'path_cost':final.get('path_cost')}
