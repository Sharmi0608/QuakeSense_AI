# Verification status at packaging

Environment: Linux container, Python 3.13, FastAPI 0.128.2, SQLAlchemy 2.0.50, pytest 9.0.2, PyTorch 2.10.0+cpu, torchvision 0.25.0+cpu, scikit-learn 1.8.0, Node 22.16.0.

- Python syntax compilation (`python -m compileall -q backend robotics ml tests`): passed.
- Automated tests (`DATABASE_URL=sqlite:////mnt/data/quakesense-ai/test_quakesense.db python -m pytest -q`): **8 passed**. Includes API health/demo seed, recommendation acceptance idempotency, override reason validation, A* route validity, obstacle avoidance, unreachable goals, start-equals-goal, and genuine dynamic replanning.
- Frontend production build: **not verified**. `npm install --no-audit --no-fund && npm run build` exceeded the execution timeout before dependencies were installed; no build success is claimed.
- Live USGS ingestion: **not verified** in this packaging run. Use the Sync USGS action after launch and report the actual response.
- PostgreSQL/PostGIS: **not verified**. Quick-start SQLite fallback is implemented. PostGIS geometry/GiST indexes and Alembic migrations are not implemented in this MVP and are explicitly documented as pending.
- CNN training/evaluation: **not run**. No xBD dataset or checkpoint is bundled; experiment status remains not evaluated until real samples are prepared and the scripts are run.
- Physical robot: not integrated; robotics is grid-world simulation only.

Known warning: FastAPI's `@app.on_event('startup')` emits a deprecation warning in the installed FastAPI version; it does not fail tests.
